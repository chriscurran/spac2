var express = require('express');
var router = express.Router();

/* GET products page. */
router.get('/', function(req, res, next) {
	var request = require("request");       // to get url data

	// lowes data url
	var url = "http://m.lowes.com/CatalogServices/product/nvalue/v1_0?nValue=4294857975&maxResults=6&showURL=1&rollUpVariants=1&showUrl=true&storeNumber=0595&priceFlag=rangeBalance&showMarketingBullets=1";

	 // issue the request and wait on reply
    request({url: url, json: true}, function (error, response, body) {

        // request is now completed.
        if (!error && response.statusCode === 200) {

            var products = [];
            for(var idx=0; idx<body.productList.length; idx++) {
                var product = body.productList[idx];
                var obj = {
                    "productId": product.productId,
                    "networkPrice": product.networkPrice,
                    "brand": product.brand,
                    "description": product.description,
                    "marketingBullets": product.marketingBullets,
                    "imageUrls": product.imageUrls
                };
                products.push(obj);
            }


  			res.render('pages/products', { title: 'Products', productList: products });
        }
    });
});

module.exports = router;
